#include "ExynosMPPModule.h"
#include "ExynosDisplay.h"

ExynosMPPModule::ExynosMPPModule(ExynosDisplay *display, int index)
    : ExynosMPP(display, index)
{
}

ExynosMPPModule::~ExynosMPPModule()
{
}
