Build the component for Android by running ndk-build in ProvisioningAgent/Android/jni
